@echo off
cd /d "%~dp0"
:loop
python regenerate_html.py
timeout /t 300 /nobreak >nul
goto loop
