import sqlite3
import json
import os
from datetime import datetime

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'prayer_times.db')
HTML_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'prayer_final.html')

def regenerate_html():
    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        today = datetime.now().strftime('%Y-%m-%d')
        cursor.execute('SELECT * FROM prayer_times WHERE date = ?', (today,))
        row = cursor.fetchone()
        conn.close()

        if row:
            prayers = [
                {"name": "بەیانی (فەجر)", "time": row[2], "key": "fajr"},
                {"name": "خۆرهەڵاتن", "time": row[3], "key": "sunrise"},
                {"name": "نیوەڕۆ (ئەسەردا)", "time": row[4], "key": "dhuhr"},
                {"name": "عەسر", "time": row[5], "key": "asr"},
                {"name": "مەغریب", "time": row[6], "key": "maghrib"},
                {"name": "عیشا", "time": row[7], "key": "isha"}
            ]
        else:
            prayers = [{"name": "هەڵە: داتا نەدۆزرایەوە", "time": "--:--", "key": "error"}]

        prayers_json = json.dumps(prayers, ensure_ascii=False)

        with open(HTML_PATH, 'r', encoding='utf-8') as f:
            html = f.read()

        import re
        pattern = r'let prayers = .*?;'
        replacement = f'let prayers = {prayers_json};'
        html = re.sub(pattern, replacement, html, count=1)

        with open(HTML_PATH, 'w', encoding='utf-8') as f:
            f.write(html)

        print(f"✅ HTML regenerated at {datetime.now().strftime('%H:%M:%S')} - {today}")

    except Exception as e:
        print(f"❌ Error: {e}")

if __name__ == '__main__':
    regenerate_html()
