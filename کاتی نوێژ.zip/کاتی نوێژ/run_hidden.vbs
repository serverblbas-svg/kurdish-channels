CreateObject("WScript.Shell").Run "run_hidden.bat", 0, False
