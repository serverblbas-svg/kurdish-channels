@echo off
cd /d "%~dp0"
python regenerate_html.py
echo Prayer times updated!
timeout /t 3
