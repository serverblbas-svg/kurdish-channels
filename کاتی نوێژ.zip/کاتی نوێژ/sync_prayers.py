import sqlite3
import json
from datetime import datetime
import os

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'prayer_times.db')
JSON_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'prayers.json')

def sync_prayers():
    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        today = datetime.now().strftime('%Y-%m-%d')
        cursor.execute('SELECT * FROM prayer_times WHERE date = ?', (today,))
        row = cursor.fetchone()
        conn.close()

        if row:
            prayers = [
                {"name": "بەیانی (فەجر)", "time": row[2], "key": "fajr"},
                {"name": "خۆرهەڵاتن", "time": row[3], "key": "sunrise"},
                {"name": "نیوەڕۆ (ئەسەردا)", "time": row[4], "key": "dhuhr"},
                {"name": "عەسر", "time": row[5], "key": "asr"},
                {"name": "مەغریب", "time": row[6], "key": "maghrib"},
                {"name": "عیشا", "time": row[7], "key": "isha"}
            ]
        else:
            prayers = [{"name": "هەڵە: داتا نەدۆزرایەوە", "time": "--:--", "key": "error"}]

        with open(JSON_PATH, 'w', encoding='utf-8') as f:
            json.dump(prayers, f, ensure_ascii=False, indent=2)

        print(f"✅ Synced at {datetime.now().strftime('%H:%M:%S')} - {today}")
    except Exception as e:
        print(f"❌ Error: {e}")

if __name__ == '__main__':
    sync_prayers()
